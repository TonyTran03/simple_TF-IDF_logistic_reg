# Candidate restaurant aspects

Unvalidated similarity suggestions; scores are not probabilities. Multiple aspects may match. English-focused anchors.

Analyzed 1777 sentences. Threshold: 0.45. Counts overlap across aspects.

| Aspect | Matching sentences | Distinct reviews |
|---|---:|---:|
| Food | 645 | 192 |
| Staff / service | 24 | 23 |
| Price / value | 174 | 107 |
| Wait times | 92 | 74 |
| Atmosphere / facilities | 63 | 54 |
| Business operations | 12 | 11 |

Examples below are highest-scoring matches, not representative samples.

## Food

- Review 84, sentence 6 (similarity 0.915): Chicken was tender and juicy.
- Review 96, sentence 8 (similarity 0.905): Chicken was flavourful, tender and juicy.
- Review 64, sentence 5 (similarity 0.902): The chicken was so good and tender.
- Review 93, sentence 8 (similarity 0.888): The chicken was tender and juicy and seasoned nicely.
- Review 147, sentence 1 (similarity 0.887): The chicken was soft and tender.

## Staff / service

- Review 93, sentence 4 (similarity 0.902): The staff is friendly and helpful.
- Review 92, sentence 2 (similarity 0.842): The staff is really friendly .
- Review 41, sentence 10 (similarity 0.692): Staff wasn't the nicest, but it's expected from places that are so crowded that are often frequented by tourists.
- Review 138, sentence 6 (similarity 0.616): The staff is quick with your order, efficient, lots of seating at the restaurant.
- Review 47, sentence 6 (similarity 0.610): The line goes quick and the staff is friendly.

## Price / value

- Review 109, sentence 5 (similarity 0.795): The prices were reasonable and the portions are huge.
- Review 172, sentence 5 (similarity 0.788): The food was very tasty and the prices were appropriate.
- Review 57, sentence 5 (similarity 0.739): It was a lot of food, but overall its a great value.
- Review 89, sentence 4 (similarity 0.725): It was also an extremely high value meal and the food is enough for two people.
- Review 90, sentence 4 (similarity 0.701): It was also an extremely high value meal as it only cost $11 and I only finished ~half in one meal.

## Wait times

- Review 105, sentence 4 (similarity 0.800): We waited around 20 minutes in line.
- Review 155, sentence 3 (similarity 0.769): Waited in line for about 15 minute.
- Review 55, sentence 5 (similarity 0.742): There was a huge line around the corner, but someone suggested we call in the order and it was ready in 15 minutes so we didn't have to wait in line.
- Review 2, sentence 3 (similarity 0.698): We waited in line for about 30-40 minutes, but it was a nice evening.
- Review 59, sentence 4 (similarity 0.685): You need to wait in line for at least 20 minutes or more but Worth the wait.

## Atmosphere / facilities

- Review 114, sentence 6 (similarity 0.738): When we went to go sit down, every single spot was completely filthy and we had to wipe down the tables ourselves.
- Review 192, sentence 2 (similarity 0.727): the ambiance of the restaurant was very comforting and felt wecloming
- Review 205, sentence 14 (similarity 0.658): They had bathrooms!
- Review 183, sentence 6 (similarity 0.646): The dining area is cozy and clean.
- Review 59, sentence 3 (similarity 0.621): got the #8 The place is small and very noisy, but they have some tables for dining in.

## Business operations

- Review 63, sentence 5 (similarity 0.572): Parking can be a bit difficult to find, but I promise it was well worth circling several times until we found a spot.
- Review 198, sentence 3 (similarity 0.568): Parking is hard not going to lie .
- Review 110, sentence 5 (similarity 0.543): Parking is tight but you can find spots in the sides streets
- Review 158, sentence 4 (similarity 0.495): This was a take-out item.
- Review 137, sentence 8 (similarity 0.477): The to-go order was def.
