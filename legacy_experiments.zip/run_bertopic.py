import pandas as pd
from bertopic import BERTopic
from bertopic.vectorizers import ClassTfidfTransformer
from sklearn.feature_extraction.text import CountVectorizer

df = pd.read_csv("reviews.csv")

reviews = df["review"].dropna().tolist()

# Keep full sentences for embeddings; filter common words in topic descriptions.
topic_model = BERTopic(
    vectorizer_model=CountVectorizer(stop_words="english", ngram_range=(1, 2)),
    ctfidf_model=ClassTfidfTransformer(reduce_frequent_words=True),
)

topics, probabilities = topic_model.fit_transform(reviews)  # 206 reviews
                                                            # ↓
                                                            # sentence transformer
                                                            # ↓
                                                            # embedding for each review
                                                            # ↓
                                                            # UMAP dimensionality reduction
                                                            # ↓
                                                            # HDBSCAN clustering
                                                            # ↓
                                                            # groups of similar reviews
                                                            # ↓
                                                            # c-TF-IDF
                                                            # ↓
                                                            # important words describing each group



print(topic_model.get_topic_info()[["Topic", "Count", "Name", "Representation"]].to_string(index=False))
