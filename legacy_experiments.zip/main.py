import pandas as pd
import numpy as np

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression


df = pd.read_csv("reviews.csv")

vectorizer = TfidfVectorizer(
    stop_words="english",
    token_pattern=r"(?u)\b[a-zA-Z][a-zA-Z]+\b"
)

# fit gets:                                    vectorizer.transform(df["review"]):                
# "poutine" → common                           ["bland", "food", "great", "poutine"] -> [0.00, 0.21, 0.74, 0.19]
#"food" → common                                                                     and another -> [0.81, 0.31, 0.00, 0.22]
# "bland" → rarer                                   #  reviews have gone from text into vectors so ml can understand
# "overpriced" → rarer

X = vectorizer.fit_transform(df["review"])

words = vectorizer.get_feature_names_out()

y = df["sentiment"]

# row = X[0]
# for col, value in zip(row.indices, row.data):
#     print(words[col], value)

words = vectorizer.get_feature_names_out()
with open("tfidf_words.txt", "w", encoding="utf-8") as f:
    for word in words:
        f.write(word + "\n")