# Sentence-level aspect candidates

## Confirm real review examples first

`aspect_references_review.md` displays 14 exact CSV excerpts with proposed
labels. Review their labels in `aspect_references.json`, edit `aspects` as needed
(multiple labels are allowed), and set `approved` to `true` only for confirmed
examples. Unapproved examples are ignored. The script stops if none are approved.
It checks each approved excerpt against its source CSV row and sentence.
Entire source reviews and duplicate reference sentences are excluded from
prediction counts to avoid self-matching. Add more diverse examples over time;
this small starter set does not cover every aspect or wording.

This is a labeled reference set for similarity matching, not model training.
For supervised training later, reserve separate reviews for validation and
testing before fitting a classifier. Do not report reference-set performance
as accuracy on unseen reviews.

Existing `aspect_results.*` files are from the previous synthetic-example run
until you approve references and rerun the script.

Run from PowerShell:

```powershell
.\.venv\Scripts\python.exe run_aspects.py
```

The script splits reviews into sentences and compares their embeddings with
example sentences for six predefined aspects. Multiple aspects can match.
It writes `aspect_results.md` with counts and top examples, and
`aspect_results.json` with every sentence, score, and candidate label.
Review IDs are one-based CSV data-row positions.

These are candidate matches, not validated classifications or sentiment labels.
The cosine similarity cutoff of 0.45 is an uncalibrated starting heuristic,
not a probability. Use `--threshold 0.55` for a stricter cutoff, at the cost of
missing more mentions. Inspect both matched and unmatched examples and tune
on manually labeled data before reporting definitive counts or accuracy.
The model and aspect examples are English-focused. Punctuation-based splitting
can mishandle abbreviations and missing punctuation. Context across sentences
is not resolved. Business operations includes parking, payment, hours, takeout,
delivery, and complaint handling; edit reference labels to match your research scope.

The method uses [Sentence Transformers semantic similarity](https://www.sbert.net/docs/sentence_transformer/usage/semantic_textual_similarity.html).
Unlike BERTopic's discovered clusters, these categories are predefined.
